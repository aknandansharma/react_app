import Navbar from "./components/NavBarComp/Navbar";
import Home from "./components/main/Home";

function App() {
  return (
    <>
        <Navbar/>
        <Home/>

    </>
  );
}

export default App;
